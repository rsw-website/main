<?php
/**
 * Product wrappers - open.
 *
 * @author     ThemeFusion
 * @copyright  (c) Copyright by ThemeFusion
 * @link       http://theme-fusion.com
 * @package    Avada
 * @subpackage Core
 * @since      5.1.0
 */

?>
<div class="fusion-product-content">
	<div class="product-details">
		<div class="product-details-container">
